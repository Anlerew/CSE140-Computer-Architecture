#include <iostream>
#include <fstream>
#include <unordered_map>
#include <string>
#include <vector>
#include <iterator>

class stage{
    public:
        string instr = "nop";
        string rtName = " ";
        string rdName = " ";
        string rsName = " ";
        int readData2 = 0; // rtVal
        int writeRegisterNumber = 0; //rdVal
        int readData1 = 0; // rsVal
        int immediate = 0;
        int address = 0;
        int aluResult = 0;

        int RegWrite= 0; 
        int RegDst= 0; 
        int Branch= 0; 
        int ALUSrc= 0; 
        int InstType= 0; 
        int MemWrite= 0; 
        int MemtoReg= 0; 
        int MemRead= 0; 
        int Jump= 0;
}

vector<int> registerFile(32,0);
vector<int> d_mem(32,0);
int jump_target= 0;
int branch_target= 0;
int alu_zero= 0;
int aluResult= 0; 
int dataRead= 0; 
int total_clock_cycles= 0; 
int ALUint = 0; 
string currInst = " ";
bool pipeline = true;
int instrCount = 0;
bool hazardOccurred = false;
int hazCount = 0;
int haz = 0;
int pc = 0;
int next_pc = 0;


using namespace std;
class Instruction {
public:
    bool operator==(const int &rightInstruction) const;
    virtual void returnPrev(long arrayR[32], unordered_map<int, int> mapObj){};
    virtual void memory(long arrayR[32], unordered_map<int, int> mapObj){};
    virtual void execute(long arrayR[32], unordered_map<int, int> mapObj, unsigned int &pc){};
    virtual ~Instruction(){};
};

unordered_map<string, string> loadI(string path) {
    unordered_map<string, string> unorderI;
    ifstream fileStream;fileStream.open(path);
    if (!fileStream) {
        cerr << "Unable to open file: " << path;
        exit(1);
    }
    string item,index;
    while (getline(fileStream, item)) {
        istringstream iss(item);
        vector<string> output(istream_iterator<string>{iss},istream_iterator<string>());
        index = output[0] + output[2];
        unorderI.insert(pair<string, string>(index, output[1]));
        
    }
    return unorderI;
}

unordered_map<int, string> loadR(string path) {
    unordered_map<int, string> unorderR;
    ifstream inFile;
    inFile.open(path);
    if (!inFile) {
        cerr << "Unable to open file: " << path;
        exit(1); 
    }
    string item,index;
    int keyInt;

    while (getline(inFile, item)) {
        istringstream iss(item);
        vector<string> output(istream_iterator<string>{iss},istream_iterator<string>());
        index = output[0];
        keyInt = atoi(index.c_str());
        unorderR.insert(pair<int, string>(keyInt, output[1]));
    }
    return unorderR;
}

int main(int argc, char *argv[]) {
    long int arrayR[32];
    for (int i = 0; i < 32; i++) arrayR[i] = 0;
    arrayR[9] = 32; arrayR[10] = 5; arrayR[16] = 112;
    unordered_map<int, int> mapObj;
    mapObj[112] = 5; mapObj[116] = 16;

    ifstream objF;
    objF.open("input.txt");
    if (!objF) {
        cerr << "Unable to open file: input.txt";
        exit(1);
    }

    vector<string> operations;
    string input;
    while (getline(objF, input)) {
        operations.push_back(input);
    }
    objF.close();
    unordered_map<string, string> mapIns;
    //Loading the files for the instruction and Register.
    mapIns = loadI("ins.txt");

    unordered_map<int, string> mapReg;
    mapReg = loadR("reg.txt");

    int fetchI = -1;
    string decodeI = "\0";
    //Init the values for the instructions
    Instruction *decodedI = NULL,*exeI = NULL,*memI = NULL,*pushI = NULL;

    unsigned int pc_ = 0,cyclesSum = 0, pc = 0;
    bool inprogress = true,timeCycle = false,validated = false;
    unsigned int ;
    while (inprogress) {
        if (exeI != NULL) {
            //have to validate the execution instruction and memory instruction.
            //TODO
            validated = validate(exeI, memI, memI);
        }
        else {
            validated = false;
        }
        cout << "total_clock_cycles " << cyclesSum + 1 << " :" << endl;

        if (!(pushI == NULL))  pushI->returnPrev(arrayR, mapObj);
        if (!(memI == NULL))  memI->memory(arrayR, mapObj);
        if (!(exeI == NULL || validated))  exeI->execute(arrayR, mapObj, pc);

        if (!(decodeI.empty() || validated)) {
            //Have to decode and validate the object.
            //TODO
            decodedI = decode(decodeI, mapReg, mapIns);
            validated = validate(decodedI, exeI, memI);

            if (validated) {
                exeI = NULL;
            }
        }

        fetchI = pc; pushI = memI; memI = exeI; exeI = decodedI;
        if (decodeI.empty()) exeI = NULL;
        if (fetchI >= 0 && !timeCycle && (fetchI / 4 <= operations.size() - 1))  decodeI = operations[fetchI / 4];
        else {
            decodeI = "";
            decodedI = NULL;
        }

        if (pc_ != pc) {
            printf("Control Hazard Detected (flush 3 instructions)\n");
            decodeI = "";
            decodedI = NULL;
            exeI = NULL;
        }

        if (!validated)  pc += 4;
        else printf("data hazard detected\n");
        pc_ = pc;
        if (!(timeCycle || validated))  printf("pc is modified to %#x\n", pc);
        cyclesSum++;
        if (pc / 4 >= operations.size() - 1) timeCycle = true;
        if (timeCycle) {
            pc = -1;
            pc_ = pc;
            if ((fetchI < 0) && decodeI.empty() && (exeI == NULL) && (memI == NULL) && (pushI == NULL)) {
                inprogress = false;
            }
        }
        cout << endl;
    }
    cout << "program terminated:" << endl;
    cout << "total execution time is " << cyclesSum << " cycles" << endl;
    return 0;
}